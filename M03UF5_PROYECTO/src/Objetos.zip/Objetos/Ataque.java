package Objetos;

public class Ataque {

}
