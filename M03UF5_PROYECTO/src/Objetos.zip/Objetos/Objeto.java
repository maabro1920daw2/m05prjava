package Objetos;

import Campeones.statsCampeon;

public class Objeto {
	protected statsCampeon stats;
}
