package Objetos;

public class Consumible {
	private int stacks;
}
